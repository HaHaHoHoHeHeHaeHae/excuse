package com.blood.coding.service.common;

import org.springframework.beans.factory.annotation.Autowired;

public class MailService {
	
	
	
}
