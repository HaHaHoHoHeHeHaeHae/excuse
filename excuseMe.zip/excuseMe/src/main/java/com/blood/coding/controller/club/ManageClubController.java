package com.blood.coding.controller.club;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/manage/club")
public class ManageClubController {
	
	@RequestMapping("/clublist")
	public String manage() throws Exception{
		String URL = "manage/club/clublist";
		return URL;
	}
	
	

}
