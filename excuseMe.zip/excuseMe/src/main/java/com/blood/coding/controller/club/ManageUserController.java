package com.blood.coding.controller.club;

import java.sql.SQLException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.blood.coding.controller.common.MemberCriteria;
import com.blood.coding.controller.common.MemberPageMaker;
import com.blood.coding.dto.member.MemberVO;
import com.blood.coding.service.member.MemberService;


@Controller
@RequestMapping("/manage/user")
public class ManageUserController {
	
	
	@Autowired
	private MemberService service;
	
	@RequestMapping("/userlist")
	public String noticeSearchList(MemberCriteria cri,Model model)throws Exception{
		String url="manage/user/userlist";
		
		MemberPageMaker pageMaker = new MemberPageMaker();
		pageMaker.setCri(cri);
		
		Map<String,Object> dataMap=service.memberlistByAdmin(pageMaker);
		
		model.addAllAttributes(dataMap);
		
		return url;		
	}
	
	@RequestMapping("/detail")
	public String detail(String mem_id, Model model)throws Exception{
		System.out.println(mem_id);
		String url="manage/user/detail";
		MemberVO member = service.selectMember(mem_id);
		
		model.addAttribute("member", member);
		
		return url;
		
	}
	
	
	@RequestMapping("/status")
	public ResponseEntity<String> update(String mem_id, 
            @RequestBody MemberVO member) throws Exception{
		  
		  ResponseEntity<String> entity = null;
		  
		 
		  try {
		  service.updateMem(member);
		  entity = new ResponseEntity<String>("SUCCESS",HttpStatus.OK);
		  }catch(SQLException e) {
		  e.printStackTrace();
		  entity = new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		  }
		  return entity;
  }
	
	

}
