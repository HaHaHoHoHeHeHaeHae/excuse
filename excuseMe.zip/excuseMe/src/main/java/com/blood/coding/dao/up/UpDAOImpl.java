package com.blood.coding.dao.up;

import java.sql.SQLException;

public class UpDAOImpl implements UpDAO {

	@Override
	public int selectUpCount(String club_no) throws SQLException {
		
		return 0;
	}

	@Override
	public void insertUp(String mem_id, String club_no) throws SQLException {
		
		
	}

	@Override
	public int checkUp(String mem_id, String club_no) throws SQLException {
		
		return 0;
	}

}
